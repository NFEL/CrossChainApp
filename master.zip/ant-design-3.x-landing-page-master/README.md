### ant design

ant design 3.0 里的 landing page。

脚手架使用的是：[antd-init](https://github.com/ant-design/antd-init)。

## preview

https://ant-motion.github.io/ant-design-3.x-landing-page/


## install
```
$ npm i 
```

## Development

```
$ npm start
```
